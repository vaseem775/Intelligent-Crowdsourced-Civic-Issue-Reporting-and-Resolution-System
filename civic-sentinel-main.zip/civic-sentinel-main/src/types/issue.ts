export type IssueCategory = 
  | 'pothole'
  | 'garbage'
  | 'water_leakage'
  | 'streetlight'
  | 'drainage'
  | 'road_damage'
  | 'other';

export type IssuePriority = 'low' | 'medium' | 'high' | 'critical';

export type IssueStatus = 
  | 'submitted'
  | 'under_review'
  | 'assigned'
  | 'in_progress'
  | 'resolved'
  | 'closed';

export interface Issue {
  id: string;
  title: string;
  description: string;
  category: IssueCategory;
  priority: IssuePriority;
  status: IssueStatus;
  imageUrl?: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  reportedBy: {
    id: string;
    name: string;
    email: string;
  };
  assignedTo?: {
    id: string;
    name: string;
    department: string;
  };
  aiAnalysis?: {
    detectedCategory: IssueCategory;
    confidence: number;
    suggestedPriority: IssuePriority;
    isDuplicate: boolean;
    duplicateOf?: string;
  };
  createdAt: Date;
  updatedAt: Date;
  resolvedAt?: Date;
  resolutionProof?: string;
}

export interface IssueStats {
  total: number;
  pending: number;
  inProgress: number;
  resolved: number;
  avgResolutionTime: number; // in hours
}

export interface AreaStats {
  areaName: string;
  issueCount: number;
  topCategory: IssueCategory;
}

export const CATEGORY_LABELS: Record<IssueCategory, string> = {
  pothole: 'Pothole',
  garbage: 'Garbage Accumulation',
  water_leakage: 'Water Leakage',
  streetlight: 'Broken Streetlight',
  drainage: 'Drainage Blockage',
  road_damage: 'Road Damage',
  other: 'Other Issue',
};

export const CATEGORY_ICONS: Record<IssueCategory, string> = {
  pothole: '🕳️',
  garbage: '🗑️',
  water_leakage: '💧',
  streetlight: '💡',
  drainage: '🚿',
  road_damage: '🛣️',
  other: '📋',
};

export const PRIORITY_COLORS: Record<IssuePriority, string> = {
  low: 'bg-success/10 text-success border-success/20',
  medium: 'bg-info/10 text-info border-info/20',
  high: 'bg-warning/10 text-warning border-warning/20',
  critical: 'bg-destructive/10 text-destructive border-destructive/20',
};

export const STATUS_COLORS: Record<IssueStatus, string> = {
  submitted: 'bg-muted text-muted-foreground',
  under_review: 'bg-info/10 text-info',
  assigned: 'bg-warning/10 text-warning',
  in_progress: 'bg-accent/10 text-accent',
  resolved: 'bg-success/10 text-success',
  closed: 'bg-muted text-muted-foreground',
};

export const STATUS_LABELS: Record<IssueStatus, string> = {
  submitted: 'Submitted',
  under_review: 'Under Review',
  assigned: 'Assigned',
  in_progress: 'In Progress',
  resolved: 'Resolved',
  closed: 'Closed',
};
