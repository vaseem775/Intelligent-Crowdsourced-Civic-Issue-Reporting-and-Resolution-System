import { Issue, IssueStats, AreaStats } from '@/types/issue';

export const mockIssues: Issue[] = [
  {
    id: '1',
    title: 'Large pothole on MG Road',
    description: 'Deep pothole causing accidents near the intersection. Multiple vehicles have been damaged.',
    category: 'pothole',
    priority: 'high',
    status: 'in_progress',
    imageUrl: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=400',
    location: {
      lat: 23.3441,
      lng: 85.3096,
      address: 'MG Road, Ranchi, Jharkhand 834001',
    },
    reportedBy: {
      id: 'u1',
      name: 'Rahul Kumar',
      email: 'rahul@example.com',
    },
    assignedTo: {
      id: 'a1',
      name: 'PWD Team Alpha',
      department: 'Public Works Department',
    },
    aiAnalysis: {
      detectedCategory: 'pothole',
      confidence: 0.94,
      suggestedPriority: 'high',
      isDuplicate: false,
    },
    createdAt: new Date('2025-01-20T10:30:00'),
    updatedAt: new Date('2025-01-22T14:00:00'),
  },
  {
    id: '2',
    title: 'Garbage pile near market',
    description: 'Garbage has been accumulating for over a week. Strong smell and hygiene concern.',
    category: 'garbage',
    priority: 'medium',
    status: 'assigned',
    imageUrl: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400',
    location: {
      lat: 23.3567,
      lng: 85.3340,
      address: 'Main Market, Doranda, Ranchi 834002',
    },
    reportedBy: {
      id: 'u2',
      name: 'Priya Singh',
      email: 'priya@example.com',
    },
    assignedTo: {
      id: 'a2',
      name: 'Sanitation Team B',
      department: 'Municipal Corporation',
    },
    aiAnalysis: {
      detectedCategory: 'garbage',
      confidence: 0.98,
      suggestedPriority: 'medium',
      isDuplicate: false,
    },
    createdAt: new Date('2025-01-21T09:15:00'),
    updatedAt: new Date('2025-01-23T11:30:00'),
  },
  {
    id: '3',
    title: 'Water leakage from main pipeline',
    description: 'Continuous water leakage wasting water and creating slippery conditions on road.',
    category: 'water_leakage',
    priority: 'critical',
    status: 'submitted',
    imageUrl: 'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?w=400',
    location: {
      lat: 23.3789,
      lng: 85.3456,
      address: 'Station Road, Ranchi 834001',
    },
    reportedBy: {
      id: 'u3',
      name: 'Amit Verma',
      email: 'amit@example.com',
    },
    aiAnalysis: {
      detectedCategory: 'water_leakage',
      confidence: 0.89,
      suggestedPriority: 'critical',
      isDuplicate: false,
    },
    createdAt: new Date('2025-01-24T16:45:00'),
    updatedAt: new Date('2025-01-24T16:45:00'),
  },
  {
    id: '4',
    title: 'Streetlight not working',
    description: 'Streetlight broken for 2 weeks. Area becomes very dark at night, safety concern.',
    category: 'streetlight',
    priority: 'medium',
    status: 'resolved',
    imageUrl: 'https://images.unsplash.com/photo-1507400492013-162706c8c05e?w=400',
    location: {
      lat: 23.3654,
      lng: 85.3123,
      address: 'Circular Road, Ranchi 834001',
    },
    reportedBy: {
      id: 'u4',
      name: 'Sunita Devi',
      email: 'sunita@example.com',
    },
    assignedTo: {
      id: 'a3',
      name: 'Electrical Team',
      department: 'Electricity Board',
    },
    aiAnalysis: {
      detectedCategory: 'streetlight',
      confidence: 0.92,
      suggestedPriority: 'medium',
      isDuplicate: false,
    },
    createdAt: new Date('2025-01-10T08:00:00'),
    updatedAt: new Date('2025-01-18T10:00:00'),
    resolvedAt: new Date('2025-01-18T10:00:00'),
    resolutionProof: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
  },
  {
    id: '5',
    title: 'Drainage blockage causing waterlogging',
    description: 'Blocked drain causing water to accumulate on road during rains.',
    category: 'drainage',
    priority: 'high',
    status: 'under_review',
    location: {
      lat: 23.3521,
      lng: 85.3278,
      address: 'Ashok Nagar, Ranchi 834002',
    },
    reportedBy: {
      id: 'u5',
      name: 'Vikram Sharma',
      email: 'vikram@example.com',
    },
    aiAnalysis: {
      detectedCategory: 'drainage',
      confidence: 0.86,
      suggestedPriority: 'high',
      isDuplicate: true,
      duplicateOf: '3',
    },
    createdAt: new Date('2025-01-23T14:20:00'),
    updatedAt: new Date('2025-01-24T09:00:00'),
  },
  {
    id: '6',
    title: 'Road damage after construction',
    description: 'Road left damaged after pipeline construction work. No repairs done.',
    category: 'road_damage',
    priority: 'low',
    status: 'submitted',
    location: {
      lat: 23.3432,
      lng: 85.3567,
      address: 'Kanke Road, Ranchi 834008',
    },
    reportedBy: {
      id: 'u6',
      name: 'Anita Kumari',
      email: 'anita@example.com',
    },
    aiAnalysis: {
      detectedCategory: 'road_damage',
      confidence: 0.78,
      suggestedPriority: 'medium',
      isDuplicate: false,
    },
    createdAt: new Date('2025-01-24T11:00:00'),
    updatedAt: new Date('2025-01-24T11:00:00'),
  },
];

export const mockStats: IssueStats = {
  total: 1247,
  pending: 342,
  inProgress: 189,
  resolved: 716,
  avgResolutionTime: 48,
};

export const mockAreaStats: AreaStats[] = [
  { areaName: 'Ranchi Central', issueCount: 234, topCategory: 'pothole' },
  { areaName: 'Doranda', issueCount: 189, topCategory: 'garbage' },
  { areaName: 'Kanke', issueCount: 156, topCategory: 'streetlight' },
  { areaName: 'Ashok Nagar', issueCount: 143, topCategory: 'drainage' },
  { areaName: 'Morabadi', issueCount: 127, topCategory: 'water_leakage' },
];

export const monthlyTrends = [
  { month: 'Sep', submitted: 145, resolved: 98 },
  { month: 'Oct', submitted: 178, resolved: 134 },
  { month: 'Nov', submitted: 201, resolved: 167 },
  { month: 'Dec', submitted: 189, resolved: 156 },
  { month: 'Jan', submitted: 234, resolved: 178 },
];

export const categoryDistribution = [
  { category: 'Pothole', count: 312, color: 'hsl(var(--destructive))' },
  { category: 'Garbage', count: 267, color: 'hsl(var(--warning))' },
  { category: 'Water Leakage', count: 198, color: 'hsl(var(--info))' },
  { category: 'Streetlight', count: 156, color: 'hsl(var(--accent))' },
  { category: 'Drainage', count: 178, color: 'hsl(var(--primary))' },
  { category: 'Other', count: 136, color: 'hsl(var(--muted-foreground))' },
];
