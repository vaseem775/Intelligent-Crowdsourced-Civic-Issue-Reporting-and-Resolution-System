import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Clock, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { mockIssues } from '@/data/mockIssues';
import { CATEGORY_LABELS, CATEGORY_ICONS, STATUS_LABELS } from '@/types/issue';
import { formatDistanceToNow } from 'date-fns';

export function RecentIssuesSection() {
  const recentIssues = mockIssues.slice(0, 3);

  const getStatusVariant = (status: string) => {
    return `status_${status}` as any;
  };

  const getPriorityVariant = (priority: string) => {
    return `priority_${priority}` as any;
  };

  return (
    <section className="py-20 bg-background">
      <div className="container">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">
              Recent Reports
            </h2>
            <p className="text-muted-foreground">
              Latest civic issues reported by citizens
            </p>
          </div>
          <Link to="/track">
            <Button variant="outline">
              View All Issues
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recentIssues.map((issue, index) => (
            <Card 
              key={issue.id}
              className="group overflow-hidden hover:shadow-medium transition-all duration-300 animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {issue.imageUrl && (
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={issue.imageUrl} 
                    alt={issue.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3 flex gap-2">
                    <Badge variant={getPriorityVariant(issue.priority)}>
                      {issue.priority.charAt(0).toUpperCase() + issue.priority.slice(1)} Priority
                    </Badge>
                  </div>
                  <div className="absolute top-3 right-3">
                    <Badge variant={getStatusVariant(issue.status)}>
                      {STATUS_LABELS[issue.status]}
                    </Badge>
                  </div>
                </div>
              )}
              
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                  <span className="text-lg">{CATEGORY_ICONS[issue.category]}</span>
                  <span>{CATEGORY_LABELS[issue.category]}</span>
                </div>
                <h3 className="font-semibold text-lg line-clamp-1">{issue.title}</h3>
              </CardHeader>
              
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                  {issue.description}
                </p>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    <span className="truncate max-w-[150px]">{issue.location.address.split(',')[0]}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span>{formatDistanceToNow(issue.createdAt, { addSuffix: true })}</span>
                  </div>
                </div>

                {issue.aiAnalysis && (
                  <div className="mt-4 pt-4 border-t">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">AI Confidence</span>
                      <span className="font-medium text-primary">
                        {Math.round(issue.aiAnalysis.confidence * 100)}%
                      </span>
                    </div>
                    <div className="mt-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full civic-gradient rounded-full transition-all duration-500"
                        style={{ width: `${issue.aiAnalysis.confidence * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
