import { Button } from '@/components/ui/button';
import { ArrowRight, Download } from 'lucide-react';
import { Link } from 'react-router-dom';

export function CTASection() {
  return (
    <section className="py-20 civic-gradient text-primary-foreground">
      <div className="container">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold">
            Be Part of the Change
          </h2>
          <p className="text-lg text-primary-foreground/80">
            Join thousands of citizens making their communities better. 
            Report issues, track progress, and see real impact.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Link to="/report">
              <Button variant="hero" size="xl" className="w-full sm:w-auto">
                Report an Issue Now
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
            <Button 
              variant="hero-outline" 
              size="xl" 
              className="w-full sm:w-auto"
              onClick={() => window.open('https://github.com/vaseem775', '_blank')}
            >
              <Download className="h-5 w-5" />
              View on GitHub
            </Button>
          </div>

          <div className="pt-8 flex flex-wrap justify-center gap-8 text-sm text-primary-foreground/60">
            <div>
              <span className="block text-2xl font-bold text-primary-foreground">5,000+</span>
              <span>Active Citizens</span>
            </div>
            <div className="hidden sm:block w-px bg-primary-foreground/20" />
            <div>
              <span className="block text-2xl font-bold text-primary-foreground">12</span>
              <span>Districts Covered</span>
            </div>
            <div className="hidden sm:block w-px bg-primary-foreground/20" />
            <div>
              <span className="block text-2xl font-bold text-primary-foreground">48h</span>
              <span>Avg Resolution</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
