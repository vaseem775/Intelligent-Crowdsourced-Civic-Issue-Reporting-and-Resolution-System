import { 
  Camera, 
  MapPin, 
  Brain, 
  BarChart3, 
  Clock, 
  Users 
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const features = [
  {
    icon: Camera,
    title: 'Image-Based Reporting',
    description: 'Upload photos of civic issues. Our CNN model automatically classifies the problem type with 94% accuracy.',
    color: 'text-info',
    bgColor: 'bg-info/10',
  },
  {
    icon: MapPin,
    title: 'Geo-Location Tagging',
    description: 'Automatic location detection using GPS. Precise mapping with OpenStreetMap integration.',
    color: 'text-accent',
    bgColor: 'bg-accent/10',
  },
  {
    icon: Brain,
    title: 'AI-Powered Analysis',
    description: 'Machine Learning algorithms detect duplicates and predict issue priority for faster resolution.',
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  {
    icon: BarChart3,
    title: 'Smart Analytics',
    description: 'Real-time dashboards showing complaint trends, area distribution, and resolution statistics.',
    color: 'text-warning',
    bgColor: 'bg-warning/10',
  },
  {
    icon: Clock,
    title: 'Real-Time Tracking',
    description: 'Track your complaint status from submission to resolution with proof of completion.',
    color: 'text-success',
    bgColor: 'bg-success/10',
  },
  {
    icon: Users,
    title: 'Citizen Engagement',
    description: 'Transparent governance with visible status updates that increase trust and participation.',
    color: 'text-destructive',
    bgColor: 'bg-destructive/10',
  },
];

export function FeaturesSection() {
  return (
    <section className="py-20 bg-background">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Intelligent Features for{' '}
            <span className="text-gradient">Smart Governance</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Leveraging Deep Learning and Machine Learning to transform how civic issues 
            are reported, analyzed, and resolved.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={feature.title} 
              className="group hover:shadow-medium transition-all duration-300 border-border/50 animate-fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6">
                <div className={`inline-flex p-3 rounded-xl ${feature.bgColor} mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className={`h-6 w-6 ${feature.color}`} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
