import { Upload, Cpu, CheckCircle, Bell } from 'lucide-react';

const steps = [
  {
    icon: Upload,
    step: '01',
    title: 'Report Issue',
    description: 'Upload a photo, add description, and location is auto-detected via GPS.',
  },
  {
    icon: Cpu,
    step: '02',
    title: 'AI Analysis',
    description: 'Our CNN model classifies the issue type and ML predicts priority level.',
  },
  {
    icon: CheckCircle,
    step: '03',
    title: 'Assignment',
    description: 'Issue is routed to the appropriate department based on category and priority.',
  },
  {
    icon: Bell,
    step: '04',
    title: 'Resolution',
    description: 'Get notified when resolved with proof. Rate the resolution quality.',
  },
];

export function HowItWorksSection() {
  return (
    <section className="py-20 civic-gradient-light">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            How It Works
          </h2>
          <p className="text-lg text-muted-foreground">
            A simple 4-step process from reporting to resolution, 
            powered by intelligent automation.
          </p>
        </div>

        <div className="relative">
          {/* Connection line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-primary/20 via-primary/40 to-primary/20 -translate-y-1/2" />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div 
                key={step.step} 
                className="relative animate-fade-in-up"
                style={{ animationDelay: `${index * 0.15}s` }}
              >
                <div className="bg-card rounded-2xl p-6 shadow-card hover:shadow-medium transition-shadow relative z-10">
                  {/* Step number */}
                  <div className="absolute -top-3 -right-3 w-10 h-10 civic-gradient rounded-full flex items-center justify-center text-primary-foreground font-bold text-sm shadow-medium">
                    {step.step}
                  </div>
                  
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                      <step.icon className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                    <p className="text-sm text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
