import { Button } from '@/components/ui/button';
import { ArrowRight, MapPin, Shield, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

export function HeroSection() {
  return (
    <section className="relative overflow-hidden hero-gradient text-primary-foreground">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="container relative py-20 md:py-28 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/20 text-accent-foreground text-sm font-medium">
              <Zap className="h-4 w-4" />
              AI-Powered Civic Solutions
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Report. Track.{' '}
              <span className="text-accent">Resolve.</span>
            </h1>

            <p className="text-lg md:text-xl text-primary-foreground/80 max-w-xl">
              An intelligent crowdsourced platform for reporting civic issues like potholes, 
              garbage, water leaks, and more. Powered by Deep Learning for faster resolution.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/report">
                <Button variant="hero" size="xl" className="w-full sm:w-auto">
                  Report an Issue
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link to="/track">
                <Button variant="hero-outline" size="xl" className="w-full sm:w-auto">
                  Track Your Complaint
                </Button>
              </Link>
            </div>

            {/* Trust indicators */}
            <div className="flex flex-wrap items-center gap-6 pt-4 text-sm text-primary-foreground/70">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-accent" />
                <span>Government Verified</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-accent" />
                <span>Geo-Location Enabled</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-accent" />
                <span>AI-Powered Analysis</span>
              </div>
            </div>
          </div>

          {/* Stats Card */}
          <div className="relative animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <div className="bg-card/10 backdrop-blur-md rounded-2xl p-8 border border-primary-foreground/10">
              <h3 className="text-xl font-semibold mb-6">Platform Statistics</h3>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <div className="text-3xl md:text-4xl font-bold text-accent">1,247</div>
                  <div className="text-sm text-primary-foreground/70">Total Complaints</div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl md:text-4xl font-bold text-accent">716</div>
                  <div className="text-sm text-primary-foreground/70">Resolved Issues</div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl md:text-4xl font-bold text-accent">48h</div>
                  <div className="text-sm text-primary-foreground/70">Avg. Resolution</div>
                </div>
                <div className="space-y-1">
                  <div className="text-3xl md:text-4xl font-bold text-accent">94%</div>
                  <div className="text-sm text-primary-foreground/70">AI Accuracy</div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-primary-foreground/10">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-primary-foreground/70">Powered by</span>
                  <div className="flex items-center gap-2 font-medium">
                    <span>Deep Learning</span>
                    <span className="text-primary-foreground/40">•</span>
                    <span>Machine Learning</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-accent/20 rounded-full blur-2xl animate-pulse-soft" />
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-accent/10 rounded-full blur-3xl animate-pulse-soft" style={{ animationDelay: '1s' }} />
          </div>
        </div>
      </div>
    </section>
  );
}
