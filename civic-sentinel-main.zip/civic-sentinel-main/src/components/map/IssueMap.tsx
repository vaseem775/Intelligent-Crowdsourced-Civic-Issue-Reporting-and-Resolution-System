import { useEffect, useState } from 'react';
import { Issue, CATEGORY_LABELS, CATEGORY_ICONS, STATUS_LABELS } from '@/types/issue';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, Loader2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface IssueMapProps {
  issues: Issue[];
  center?: [number, number];
  zoom?: number;
  height?: string;
  onIssueClick?: (issue: Issue) => void;
  showClustering?: boolean;
}

export function IssueMap({ 
  issues, 
  center = [23.3441, 85.3096],
  zoom = 12,
  height = '400px',
  onIssueClick,
  showClustering = true
}: IssueMapProps) {
  const [MapComponents, setMapComponents] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Dynamic import to avoid SSR issues
    const loadMap = async () => {
      try {
        const [leafletModule, reactLeafletModule, clusterModule] = await Promise.all([
          import('leaflet'),
          import('react-leaflet'),
          import('react-leaflet-cluster'),
        ]);
        
        // Import CSS
        await import('leaflet/dist/leaflet.css');

        const L = leafletModule.default;
        
        // Fix marker icons
        delete (L.Icon.Default.prototype as any)._getIconUrl;
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
          iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
          shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
        });

        setMapComponents({
          L,
          MapContainer: reactLeafletModule.MapContainer,
          TileLayer: reactLeafletModule.TileLayer,
          Marker: reactLeafletModule.Marker,
          Popup: reactLeafletModule.Popup,
          useMap: reactLeafletModule.useMap,
          MarkerClusterGroup: clusterModule.default,
        });
        setIsLoading(false);
      } catch (error) {
        console.error('Failed to load map:', error);
        setIsLoading(false);
      }
    };

    loadMap();
  }, []);

  if (isLoading || !MapComponents) {
    return (
      <div 
        style={{ height }} 
        className="rounded-xl overflow-hidden shadow-card border bg-muted flex items-center justify-center"
      >
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    );
  }

  const { L, MapContainer, TileLayer, Marker, Popup, useMap, MarkerClusterGroup } = MapComponents;

  const createCustomIcon = (priority: string) => {
    const colors: Record<string, string> = {
      low: '#10b981',
      medium: '#0ea5e9',
      high: '#f59e0b',
      critical: '#ef4444',
    };

    return L.divIcon({
      className: 'custom-marker',
      html: `
        <div style="
          background-color: ${colors[priority] || colors.medium};
          width: 32px;
          height: 32px;
          border-radius: 50% 50% 50% 0;
          transform: rotate(-45deg);
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          border: 2px solid white;
        ">
          <span style="transform: rotate(45deg); font-size: 14px;">📍</span>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 32],
      popupAnchor: [0, -32],
    });
  };

  const createClusterCustomIcon = (cluster: any) => {
    const count = cluster.getChildCount();
    const size = count >= 25 ? 52 : count >= 10 ? 44 : 36;

    return L.divIcon({
      html: `
        <div style="
          background: linear-gradient(135deg, hsl(213, 56%, 24%) 0%, hsl(199, 89%, 35%) 100%);
          width: ${size}px;
          height: ${size}px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-weight: bold;
          font-size: ${count >= 100 ? '12px' : '14px'};
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          border: 3px solid white;
        ">
          ${count}
        </div>
      `,
      className: 'custom-cluster-icon',
      iconSize: L.point(size, size),
    });
  };

  const getStatusVariant = (status: string) => `status_${status}` as any;
  const getPriorityVariant = (priority: string) => `priority_${priority}` as any;

  const markers = issues.map((issue) => (
    <Marker
      key={issue.id}
      position={[issue.location.lat, issue.location.lng]}
      icon={createCustomIcon(issue.priority)}
      eventHandlers={{
        click: () => onIssueClick?.(issue),
      }}
    >
      <Popup maxWidth={300}>
        <div className="p-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-lg">{CATEGORY_ICONS[issue.category]}</span>
            <span className="text-xs text-muted-foreground font-mono">#{issue.id}</span>
          </div>
          
          <h3 className="font-semibold text-sm mb-1 line-clamp-2">{issue.title}</h3>
          <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{issue.description}</p>
          
          <div className="flex flex-wrap gap-1 mb-2">
            <Badge variant={getPriorityVariant(issue.priority)} className="text-[10px] px-1.5 py-0">
              {issue.priority}
            </Badge>
            <Badge variant={getStatusVariant(issue.status)} className="text-[10px] px-1.5 py-0">
              {STATUS_LABELS[issue.status]}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
            <MapPin className="h-3 w-3" />
            <span className="truncate">{issue.location.address.split(',')[0]}</span>
          </div>
          
          <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-1">
            <Clock className="h-3 w-3" />
            <span>{formatDistanceToNow(issue.createdAt, { addSuffix: true })}</span>
          </div>

          {issue.imageUrl && (
            <img 
              src={issue.imageUrl} 
              alt={issue.title}
              className="w-full h-20 object-cover rounded mt-2"
            />
          )}
        </div>
      </Popup>
    </Marker>
  ));

  return (
    <div style={{ height }} className="rounded-xl overflow-hidden shadow-card border">
      <MapContainer
        center={center}
        zoom={zoom}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {showClustering ? (
          <MarkerClusterGroup
            chunkedLoading
            iconCreateFunction={createClusterCustomIcon}
            maxClusterRadius={60}
            spiderfyOnMaxZoom={true}
            showCoverageOnHover={false}
          >
            {markers}
          </MarkerClusterGroup>
        ) : (
          markers
        )}
      </MapContainer>
    </div>
  );
}
