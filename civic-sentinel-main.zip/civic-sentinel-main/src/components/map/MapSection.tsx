import { useState } from 'react';
import { IssueMap } from './IssueMap';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { mockIssues } from '@/data/mockIssues';
import { Issue, CATEGORY_LABELS, CATEGORY_ICONS, STATUS_LABELS, IssueCategory } from '@/types/issue';
import { MapPin, Filter, Layers, X } from 'lucide-react';

const categoryFilters: { value: IssueCategory | 'all'; label: string; icon: string }[] = [
  { value: 'all', label: 'All Issues', icon: '📋' },
  { value: 'pothole', label: 'Potholes', icon: '🕳️' },
  { value: 'garbage', label: 'Garbage', icon: '🗑️' },
  { value: 'water_leakage', label: 'Water Leakage', icon: '💧' },
  { value: 'streetlight', label: 'Streetlights', icon: '💡' },
  { value: 'drainage', label: 'Drainage', icon: '🚿' },
];

export function MapSection() {
  const [selectedCategory, setSelectedCategory] = useState<IssueCategory | 'all'>('all');
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);

  const filteredIssues = selectedCategory === 'all' 
    ? mockIssues 
    : mockIssues.filter(issue => issue.category === selectedCategory);

  const getStatusVariant = (status: string) => `status_${status}` as any;
  const getPriorityVariant = (priority: string) => `priority_${priority}` as any;

  return (
    <section className="py-20 bg-muted/30">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Issue Map
          </h2>
          <p className="text-lg text-muted-foreground">
            Explore reported civic issues across Jharkhand. Click on markers to view details.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Map */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    <CardTitle>Live Issue Map</CardTitle>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">
                      {filteredIssues.length} issues
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0 sm:p-6 sm:pt-0">
                <IssueMap 
                  issues={filteredIssues}
                  height="500px"
                  onIssueClick={setSelectedIssue}
                />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Filters */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-primary" />
                  <CardTitle className="text-base">Filter by Category</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {categoryFilters.map((filter) => (
                    <Button
                      key={filter.value}
                      variant={selectedCategory === filter.value ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedCategory(filter.value)}
                      className="text-xs"
                    >
                      <span>{filter.icon}</span>
                      {filter.label}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Legend */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <Layers className="h-4 w-4 text-primary" />
                  <CardTitle className="text-base">Priority Legend</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { priority: 'critical', color: '#ef4444', label: 'Critical' },
                    { priority: 'high', color: '#f59e0b', label: 'High' },
                    { priority: 'medium', color: '#0ea5e9', label: 'Medium' },
                    { priority: 'low', color: '#10b981', label: 'Low' },
                  ].map((item) => (
                    <div key={item.priority} className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-sm">{item.label} Priority</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Selected Issue */}
            {selectedIssue && (
              <Card className="animate-fade-in">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">Selected Issue</CardTitle>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6"
                      onClick={() => setSelectedIssue(null)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {selectedIssue.imageUrl && (
                    <img 
                      src={selectedIssue.imageUrl}
                      alt={selectedIssue.title}
                      className="w-full h-32 object-cover rounded-lg mb-3"
                    />
                  )}
                  
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">{CATEGORY_ICONS[selectedIssue.category]}</span>
                    <span className="text-xs text-muted-foreground">
                      {CATEGORY_LABELS[selectedIssue.category]}
                    </span>
                  </div>
                  
                  <h4 className="font-semibold mb-1">{selectedIssue.title}</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    {selectedIssue.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-3">
                    <Badge variant={getPriorityVariant(selectedIssue.priority)}>
                      {selectedIssue.priority} priority
                    </Badge>
                    <Badge variant={getStatusVariant(selectedIssue.status)}>
                      {STATUS_LABELS[selectedIssue.status]}
                    </Badge>
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    <MapPin className="h-3 w-3 inline mr-1" />
                    {selectedIssue.location.address}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
