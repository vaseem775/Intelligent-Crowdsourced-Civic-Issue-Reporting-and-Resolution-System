import { useState, useEffect } from 'react';
import { MapPin, Loader2 } from 'lucide-react';

interface LocationPickerMapProps {
  onLocationSelect: (lat: number, lng: number) => void;
  initialPosition?: [number, number];
}

export function LocationPickerMap({ onLocationSelect, initialPosition }: LocationPickerMapProps) {
  const [MapComponents, setMapComponents] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [markerPosition, setMarkerPosition] = useState<[number, number] | null>(initialPosition || null);

  const defaultCenter: [number, number] = [23.3441, 85.3096]; // Ranchi

  useEffect(() => {
    const loadMap = async () => {
      try {
        const [leafletModule, reactLeafletModule] = await Promise.all([
          import('leaflet'),
          import('react-leaflet'),
        ]);
        
        await import('leaflet/dist/leaflet.css');

        const L = leafletModule.default;
        
        // Fix marker icons
        delete (L.Icon.Default.prototype as any)._getIconUrl;
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
          iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
          shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
        });

        setMapComponents({
          L,
          MapContainer: reactLeafletModule.MapContainer,
          TileLayer: reactLeafletModule.TileLayer,
          Marker: reactLeafletModule.Marker,
          useMapEvents: reactLeafletModule.useMapEvents,
          useMap: reactLeafletModule.useMap,
        });
        setIsLoading(false);
      } catch (error) {
        console.error('Failed to load map:', error);
        setIsLoading(false);
      }
    };

    loadMap();
  }, []);

  if (isLoading || !MapComponents) {
    return (
      <div className="relative rounded-xl overflow-hidden border shadow-sm h-[200px] bg-muted flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto mb-2" />
          <p className="text-xs text-muted-foreground">Loading map...</p>
        </div>
      </div>
    );
  }

  const { L, MapContainer, TileLayer, Marker, useMapEvents, useMap } = MapComponents;

  const locationIcon = L.divIcon({
    className: 'custom-location-marker',
    html: `
      <div style="
        background: linear-gradient(135deg, hsl(160, 84%, 39%) 0%, hsl(160, 84%, 30%) 100%);
        width: 36px;
        height: 36px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        border: 3px solid white;
      ">
        <span style="transform: rotate(45deg); font-size: 16px;">📍</span>
      </div>
    `,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
  });

  function MapClickHandler() {
    useMapEvents({
      click: (e: any) => {
        const { lat, lng } = e.latlng;
        setMarkerPosition([lat, lng]);
        onLocationSelect(lat, lng);
      },
    });
    return null;
  }

  return (
    <div className="relative rounded-xl overflow-hidden border shadow-sm">
      <MapContainer
        center={initialPosition || defaultCenter}
        zoom={13}
        style={{ height: '200px', width: '100%' }}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapClickHandler />
        
        {markerPosition && (
          <Marker position={markerPosition} icon={locationIcon} />
        )}
      </MapContainer>
      
      {!markerPosition && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none bg-background/20">
          <div className="bg-card/90 backdrop-blur-sm px-4 py-2 rounded-lg shadow-md text-sm text-muted-foreground flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Click on map to set location
          </div>
        </div>
      )}
    </div>
  );
}
