import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground hover:bg-primary/80",
        secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "border-transparent bg-destructive text-destructive-foreground hover:bg-destructive/80",
        outline: "text-foreground",
        success: "border-transparent bg-success/10 text-success border-success/20",
        warning: "border-transparent bg-warning/10 text-warning border-warning/20",
        info: "border-transparent bg-info/10 text-info border-info/20",
        critical: "border-transparent bg-destructive/10 text-destructive border-destructive/20",
        priority_low: "border-transparent bg-success/10 text-success border border-success/20",
        priority_medium: "border-transparent bg-info/10 text-info border border-info/20",
        priority_high: "border-transparent bg-warning/10 text-warning border border-warning/20",
        priority_critical: "border-transparent bg-destructive/10 text-destructive border border-destructive/20",
        status_submitted: "border-transparent bg-muted text-muted-foreground",
        status_under_review: "border-transparent bg-info/10 text-info",
        status_assigned: "border-transparent bg-warning/10 text-warning",
        status_in_progress: "border-transparent bg-accent/10 text-accent",
        status_resolved: "border-transparent bg-success/10 text-success",
        status_closed: "border-transparent bg-muted text-muted-foreground",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
