import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, MapPin, Clock, Filter, Brain, AlertTriangle, Loader2 } from 'lucide-react';
import { CATEGORY_LABELS, CATEGORY_ICONS, STATUS_LABELS, IssueStatus, IssueCategory } from '@/types/issue';
import { formatDistanceToNow } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

interface DBIssue {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: string;
  status: string;
  image_url: string | null;
  address: string;
  latitude: number | null;
  longitude: number | null;
  ai_detected_category: string | null;
  ai_confidence: number | null;
  ai_suggested_priority: string | null;
  is_duplicate: boolean | null;
  created_at: string;
  updated_at: string;
}

export default function TrackIssue() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [issues, setIssues] = useState<DBIssue[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<IssueStatus | 'all'>('all');

  useEffect(() => {
    if (!user) return;
    fetchIssues();
  }, [user]);

  const fetchIssues = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('issues')
      .select('*')
      .eq('reporter_id', user!.id)
      .order('created_at', { ascending: false });
    if (!error && data) setIssues(data);
    setLoading(false);
  };

  const filteredIssues = issues.filter(issue => {
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.id.includes(searchQuery) ||
      issue.address.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || issue.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const statusTabs: { value: IssueStatus | 'all'; label: string; count: number }[] = [
    { value: 'all', label: 'All Issues', count: issues.length },
    { value: 'submitted', label: 'Submitted', count: issues.filter(i => i.status === 'submitted').length },
    { value: 'in_progress', label: 'In Progress', count: issues.filter(i => i.status === 'in_progress').length },
    { value: 'resolved', label: 'Resolved', count: issues.filter(i => i.status === 'resolved').length },
  ];

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <Card className="max-w-md w-full mx-4">
            <CardContent className="p-8 text-center">
              <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-xl font-semibold mb-2">Login Required</h2>
              <p className="text-muted-foreground mb-4">Please login to track your complaints.</p>
              <Button onClick={() => navigate('/login')}>Go to Login</Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-8 bg-muted/30">
        <div className="container">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Track Your Complaints</h1>
            <p className="text-muted-foreground">Search by complaint ID, title, or location to track status</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by ID, title, or location..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10" />
            </div>
            <Button variant="outline"><Filter className="h-4 w-4" /> Filters</Button>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <Tabs value={selectedStatus} onValueChange={(v) => setSelectedStatus(v as IssueStatus | 'all')}>
              <TabsList className="mb-6 w-full justify-start overflow-x-auto">
                {statusTabs.map(tab => (
                  <TabsTrigger key={tab.value} value={tab.value} className="gap-2">
                    {tab.label}
                    <Badge variant="secondary" className="h-5 px-1.5 text-xs">{tab.count}</Badge>
                  </TabsTrigger>
                ))}
              </TabsList>
              <TabsContent value={selectedStatus} className="mt-0">
                <div className="grid gap-4">
                  {filteredIssues.length === 0 ? (
                    <Card className="p-12 text-center">
                      <Search className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                      <h3 className="text-lg font-semibold mb-2">No issues found</h3>
                      <p className="text-muted-foreground">Try adjusting your search or report a new issue</p>
                    </Card>
                  ) : (
                    filteredIssues.map((issue, index) => (
                      <Card key={issue.id} className="hover:shadow-medium transition-shadow animate-fade-in-up" style={{ animationDelay: `${index * 0.05}s` }}>
                        <CardContent className="p-6">
                          <div className="flex flex-col lg:flex-row gap-6">
                            {issue.image_url && (
                              <div className="w-full lg:w-48 h-32 lg:h-auto rounded-lg overflow-hidden flex-shrink-0">
                                <img src={issue.image_url} alt={issue.title} className="w-full h-full object-cover" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                                <div className="flex items-center gap-2">
                                  <span className="text-lg">{CATEGORY_ICONS[issue.category as IssueCategory] || '📋'}</span>
                                  <span className="text-sm text-muted-foreground">{CATEGORY_LABELS[issue.category as IssueCategory] || issue.category}</span>
                                  <span className="text-muted-foreground">•</span>
                                  <span className="text-sm font-mono text-muted-foreground">#{issue.id.slice(0, 8)}</span>
                                </div>
                                <div className="flex gap-2">
                                  <Badge variant={`priority_${issue.priority}` as any}>{issue.priority}</Badge>
                                  <Badge variant={`status_${issue.status}` as any}>{STATUS_LABELS[issue.status as IssueStatus] || issue.status}</Badge>
                                </div>
                              </div>
                              <h3 className="text-lg font-semibold mb-1">{issue.title}</h3>
                              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{issue.description}</p>
                              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                                <div className="flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  <span className="truncate max-w-[200px]">{issue.address}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Clock className="h-4 w-4" />
                                  <span>{formatDistanceToNow(new Date(issue.created_at), { addSuffix: true })}</span>
                                </div>
                              </div>
                              {issue.ai_confidence && (
                                <div className="mt-4 pt-4 border-t flex flex-wrap items-center gap-4">
                                  <div className="flex items-center gap-2 text-sm">
                                    <Brain className="h-4 w-4 text-primary" />
                                    <span className="text-muted-foreground">AI Confidence:</span>
                                    <span className="font-medium">{Math.round(issue.ai_confidence * 100)}%</span>
                                  </div>
                                  {issue.is_duplicate && (
                                    <div className="flex items-center gap-2 text-sm text-warning">
                                      <AlertTriangle className="h-4 w-4" />
                                      <span>Potential duplicate</span>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
