import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Camera, MapPin, Send, Upload, Loader2, CheckCircle2, Brain } from 'lucide-react';
import { CATEGORY_LABELS, CATEGORY_ICONS, IssueCategory } from '@/types/issue';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

export default function ReportIssue() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState<{category: IssueCategory; confidence: number} | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '' as IssueCategory | '',
    location: '',
  });
  const [coordinates, setCoordinates] = useState<{ lat: number; lng: number } | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        analyzeImageWithAI(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImageWithAI = async (imageBase64: string) => {
    setIsAnalyzing(true);
    try {
      const { data, error } = await supabase.functions.invoke('classify-image', {
        body: { imageBase64 },
      });

      if (error) throw error;

      if (data?.error) {
        toast.error('AI Analysis Error', { description: data.error });
        setIsAnalyzing(false);
        return;
      }

      const category = data.category as IssueCategory;
      const confidence = data.confidence as number;
      setAiSuggestion({ category, confidence });
      setFormData(prev => ({ ...prev, category }));
      toast.success('AI Analysis Complete', {
        description: `Detected: ${CATEGORY_LABELS[category]} (${Math.round(confidence * 100)}% confidence)`,
      });
    } catch (err: any) {
      console.error('AI analysis failed:', err);
      toast.error('AI analysis failed', { description: 'Please select the category manually.' });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setCoordinates({ lat: latitude, lng: longitude });
          setFormData(prev => ({
            ...prev,
            location: `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)} - Ranchi, Jharkhand`
          }));
          toast.success('Location detected successfully!');
        },
        () => {
          toast.error('Could not get location. Please enter manually.');
        }
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error('Please login to report an issue');
      navigate('/login');
      return;
    }

    setIsSubmitting(true);
    try {
      let imageUrl: string | null = null;

      // Upload image to storage
      if (imageFile) {
        const fileExt = imageFile.name.split('.').pop();
        const filePath = `${user.id}/${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('issue-images')
          .upload(filePath, imageFile);
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage.from('issue-images').getPublicUrl(filePath);
        imageUrl = urlData.publicUrl;
      }

      // Insert issue into database
      const { error } = await supabase.from('issues').insert({
        reporter_id: user.id,
        title: formData.title,
        description: formData.description,
        category: formData.category || 'other',
        priority: aiSuggestion ? (aiSuggestion.confidence > 0.9 ? 'high' : 'medium') : 'medium',
        image_url: imageUrl,
        latitude: coordinates?.lat,
        longitude: coordinates?.lng,
        address: formData.location,
        ai_detected_category: aiSuggestion?.category,
        ai_confidence: aiSuggestion?.confidence,
        ai_suggested_priority: aiSuggestion ? (aiSuggestion.confidence > 0.9 ? 'high' : 'medium') : null,
      });

      if (error) throw error;

      toast.success('Issue Reported Successfully!', {
        description: 'Your complaint has been submitted and is under review.',
      });
      navigate('/track');
    } catch (err: any) {
      toast.error('Failed to submit issue', { description: err.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <Card className="max-w-md w-full mx-4">
            <CardContent className="p-8 text-center">
              <MapPin className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-xl font-semibold mb-2">Login Required</h2>
              <p className="text-muted-foreground mb-4">Please login to report a civic issue.</p>
              <Button onClick={() => navigate('/login')}>Go to Login</Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 py-8 bg-muted/30">
        <div className="container max-w-4xl">
          <div className="mb-8 text-center">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Report a Civic Issue</h1>
            <p className="text-muted-foreground">
              Help improve your community by reporting issues. Our AI will analyze and prioritize your report.
            </p>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="md:row-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className="h-5 w-5 text-primary" />
                    Upload Image
                  </CardTitle>
                  <CardDescription>Take a photo or upload an image of the issue</CardDescription>
                </CardHeader>
                <CardContent>
                  <div
                    className="relative border-2 border-dashed rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer min-h-[300px] flex flex-col items-center justify-center"
                    onClick={() => document.getElementById('image-upload')?.click()}
                  >
                    {imagePreview ? (
                      <>
                        <img src={imagePreview} alt="Preview" className="max-h-[250px] rounded-lg object-contain" />
                        {isAnalyzing && (
                          <div className="absolute inset-0 bg-background/80 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center">
                            <Brain className="h-12 w-12 text-primary animate-pulse" />
                            <p className="mt-4 font-medium">AI Analyzing Image...</p>
                            <p className="text-sm text-muted-foreground">CNN Classification in progress</p>
                          </div>
                        )}
                      </>
                    ) : (
                      <>
                        <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                        <p className="font-medium">Click to upload image</p>
                        <p className="text-sm text-muted-foreground">or drag and drop</p>
                      </>
                    )}
                    <input id="image-upload" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                  </div>

                  {aiSuggestion && (
                    <div className="mt-4 p-4 rounded-lg bg-success/10 border border-success/20">
                      <div className="flex items-center gap-2 text-success font-medium mb-2">
                        <CheckCircle2 className="h-4 w-4" />
                        AI Detection Result
                      </div>
                      <p className="text-sm text-muted-foreground">
                        Detected: <strong>{CATEGORY_LABELS[aiSuggestion.category]}</strong>
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Confidence: <strong>{Math.round(aiSuggestion.confidence * 100)}%</strong>
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Issue Details</CardTitle>
                  <CardDescription>Provide details about the civic issue</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Issue Title</Label>
                    <Input id="title" placeholder="e.g., Large pothole on MG Road" value={formData.title} onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value as IssueCategory }))}>
                      <SelectTrigger><SelectValue placeholder="Select issue category" /></SelectTrigger>
                      <SelectContent>
                        {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                          <SelectItem key={key} value={key}>
                            <span className="flex items-center gap-2">{CATEGORY_ICONS[key as IssueCategory]} {label}</span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" placeholder="Describe the issue in detail..." rows={4} value={formData.description} onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))} required />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    Location
                  </CardTitle>
                  <CardDescription>We'll auto-detect your location or you can enter manually</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">Address / Location</Label>
                    <div className="flex gap-2">
                      <Input id="location" placeholder="Click detect or enter manually" value={formData.location} onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))} className="flex-1" required />
                      <Button type="button" variant="outline" onClick={handleGetLocation}>
                        <MapPin className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="h-40 rounded-lg bg-muted flex items-center justify-center text-sm text-muted-foreground border-2 border-dashed">
                    <div className="text-center">
                      <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p>OpenStreetMap will display here</p>
                      <p className="text-xs">Location: {coordinates ? `${coordinates.lat.toFixed(4)}, ${coordinates.lng.toFixed(4)}` : 'Not selected'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mt-6 flex justify-end">
              <Button type="submit" size="lg" disabled={isSubmitting || !formData.title || !formData.category || !formData.location}>
                {isSubmitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Submitting...</> : <><Send className="h-4 w-4" /> Submit Report</>}
              </Button>
            </div>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
}
