import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Search, Filter, Brain, AlertTriangle, CheckCircle2, Clock, Users,
  BarChart3, MapPin, ArrowUpRight, Settings, Loader2, ShieldAlert
} from 'lucide-react';
import { CATEGORY_LABELS, CATEGORY_ICONS, STATUS_LABELS, IssueStatus } from '@/types/issue';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

interface DBIssue {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: string;
  status: string;
  image_url: string | null;
  address: string;
  ai_detected_category: string | null;
  ai_confidence: number | null;
  ai_suggested_priority: string | null;
  is_duplicate: boolean | null;
  assigned_to_name: string | null;
  assigned_to_department: string | null;
  created_at: string;
}

export default function AdminDashboard() {
  const { user, isAdmin, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [issues, setIssues] = useState<DBIssue[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIssue, setSelectedIssue] = useState<DBIssue | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (!authLoading && user) fetchIssues();
    if (!authLoading && !user) setLoading(false);
  }, [user, authLoading]);

  const fetchIssues = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('issues')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) setIssues(data);
    setLoading(false);
  };

  const handleStatusUpdate = async (issueId: string, newStatus: IssueStatus) => {
    const updateData: any = { status: newStatus };
    if (newStatus === 'resolved') updateData.resolved_at = new Date().toISOString();
    const { error } = await supabase.from('issues').update(updateData).eq('id', issueId);
    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success('Status Updated', { description: `Issue status changed to ${STATUS_LABELS[newStatus]}` });
      fetchIssues();
      if (selectedIssue?.id === issueId) {
        setSelectedIssue(prev => prev ? { ...prev, status: newStatus } : null);
      }
    }
  };

  const handleAssign = async (issueId: string) => {
    const { error } = await supabase.from('issues').update({
      assigned_to_name: 'PWD Officer',
      assigned_to_department: 'Public Works Department',
      status: 'assigned',
    }).eq('id', issueId);
    if (error) {
      toast.error('Failed to assign');
    } else {
      toast.success('Issue Assigned to PWD Team');
      fetchIssues();
    }
  };

  const filteredIssues = issues.filter(issue =>
    issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    issue.id.includes(searchQuery)
  );

  const stats = {
    total: issues.length,
    pending: issues.filter(i => ['submitted', 'under_review'].includes(i.status)).length,
    inProgress: issues.filter(i => ['assigned', 'in_progress'].includes(i.status)).length,
    resolved: issues.filter(i => ['resolved', 'closed'].includes(i.status)).length,
  };

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <Card className="max-w-md w-full mx-4">
            <CardContent className="p-8 text-center">
              <ShieldAlert className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-xl font-semibold mb-2">Admin Access Required</h2>
              <p className="text-muted-foreground mb-4">Please login with an admin account.</p>
              <Button onClick={() => navigate('/login')}>Go to Login</Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/30">
      <Header />
      <main className="flex-1 py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-1">Admin Dashboard</h1>
              <p className="text-muted-foreground">Manage and resolve civic issues efficiently</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm"><Settings className="h-4 w-4" /> Settings</Button>
              <Button variant="default" size="sm"><BarChart3 className="h-4 w-4" /> Generate Report</Button>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card><CardContent className="p-4"><div className="flex items-center gap-3"><div className="h-10 w-10 rounded-lg bg-destructive/10 flex items-center justify-center"><AlertTriangle className="h-5 w-5 text-destructive" /></div><div><p className="text-2xl font-bold">{stats.pending}</p><p className="text-sm text-muted-foreground">Pending</p></div></div></CardContent></Card>
            <Card><CardContent className="p-4"><div className="flex items-center gap-3"><div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center"><Clock className="h-5 w-5 text-warning" /></div><div><p className="text-2xl font-bold">{stats.inProgress}</p><p className="text-sm text-muted-foreground">In Progress</p></div></div></CardContent></Card>
            <Card><CardContent className="p-4"><div className="flex items-center gap-3"><div className="h-10 w-10 rounded-lg bg-success/10 flex items-center justify-center"><CheckCircle2 className="h-5 w-5 text-success" /></div><div><p className="text-2xl font-bold">{stats.resolved}</p><p className="text-sm text-muted-foreground">Resolved</p></div></div></CardContent></Card>
            <Card><CardContent className="p-4"><div className="flex items-center gap-3"><div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center"><Users className="h-5 w-5 text-primary" /></div><div><p className="text-2xl font-bold">{stats.total}</p><p className="text-sm text-muted-foreground">Total</p></div></div></CardContent></Card>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <CardTitle>Complaint Queue</CardTitle>
                      <div className="flex gap-2">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9 w-[200px]" />
                        </div>
                        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="divide-y max-h-[600px] overflow-y-auto">
                      {filteredIssues.map((issue) => (
                        <div
                          key={issue.id}
                          className={`p-4 hover:bg-muted/50 cursor-pointer transition-colors ${selectedIssue?.id === issue.id ? 'bg-muted/50' : ''}`}
                          onClick={() => setSelectedIssue(issue)}
                        >
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-sm font-mono text-muted-foreground">#{issue.id.slice(0, 8)}</span>
                                <Badge variant={`priority_${issue.priority}` as any} className="text-xs">{issue.priority}</Badge>
                                <Badge variant={`status_${issue.status}` as any} className="text-xs">{STATUS_LABELS[issue.status as IssueStatus] || issue.status}</Badge>
                              </div>
                              <h4 className="font-medium truncate">{issue.title}</h4>
                              <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                                <span className="flex items-center gap-1">{CATEGORY_ICONS[issue.category as keyof typeof CATEGORY_ICONS] || '📋'} {CATEGORY_LABELS[issue.category as keyof typeof CATEGORY_LABELS] || issue.category}</span>
                                <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{formatDistanceToNow(new Date(issue.created_at), { addSuffix: true })}</span>
                              </div>
                            </div>
                            {issue.ai_confidence && (
                              <div className="text-right">
                                <div className="flex items-center gap-1 text-xs text-primary"><Brain className="h-3 w-3" />{Math.round(issue.ai_confidence * 100)}%</div>
                                {issue.is_duplicate && <Badge variant="outline" className="text-xs mt-1">Duplicate</Badge>}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                      {filteredIssues.length === 0 && (
                        <div className="p-8 text-center text-muted-foreground">No issues found</div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card className="sticky top-24">
                  <CardHeader>
                    <CardTitle>Issue Details</CardTitle>
                    <CardDescription>{selectedIssue ? `Viewing #${selectedIssue.id.slice(0, 8)}` : 'Select an issue to view details'}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {selectedIssue ? (
                      <div className="space-y-4">
                        {selectedIssue.image_url && (
                          <div className="rounded-lg overflow-hidden">
                            <img src={selectedIssue.image_url} alt={selectedIssue.title} className="w-full h-40 object-cover" />
                          </div>
                        )}
                        <div>
                          <h3 className="font-semibold mb-1">{selectedIssue.title}</h3>
                          <p className="text-sm text-muted-foreground">{selectedIssue.description}</p>
                        </div>
                        <div className="flex items-center gap-2 text-sm">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{selectedIssue.address}</span>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Update Status</label>
                          <Select value={selectedIssue.status} onValueChange={(v) => handleStatusUpdate(selectedIssue.id, v as IssueStatus)}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {Object.entries(STATUS_LABELS).map(([key, label]) => (
                                <SelectItem key={key} value={key}>{label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        {selectedIssue.ai_confidence && (
                          <div className="p-3 rounded-lg bg-muted/50">
                            <div className="flex items-center gap-2 text-sm font-medium mb-2"><Brain className="h-4 w-4 text-primary" /> AI Analysis</div>
                            <div className="space-y-1 text-sm text-muted-foreground">
                              <p>Category: {CATEGORY_LABELS[selectedIssue.ai_detected_category as keyof typeof CATEGORY_LABELS] || selectedIssue.ai_detected_category}</p>
                              <p>Confidence: {Math.round(selectedIssue.ai_confidence * 100)}%</p>
                              <p>Suggested Priority: {selectedIssue.ai_suggested_priority}</p>
                            </div>
                          </div>
                        )}
                        <div className="flex gap-2 pt-2">
                          <Button className="flex-1" onClick={() => handleAssign(selectedIssue.id)}>Assign Team</Button>
                          <Button variant="outline"><ArrowUpRight className="h-4 w-4" /></Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-muted-foreground">
                        <AlertTriangle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>Click on an issue to view details and take action</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
